a = pi/2;
xmin = 0;
xmax = 4*pi;
nrx = 500;

x = linspace(xmin,xmax,nrx);
%x = 0:0.1:4*pi;
f = sin(x);
g = a*x.*f;


figure 

subplot(2,1,1);
plot(x,f,'black');
grid on
xlabel('x')
ylabel('f(x)')
title('f(x) graph')

subplot(2,1,2);
plot(x,g,'green')
grid on
xlabel('x')
ylabel('g(x)')
title('g(x) graph')

figure
plot(x,f);
grid on
xlabel('x')
legend('f(x)','g(x)')
title('f(x) and g(x) graph')

hold on

plot (x,g)
grid on
