xmin = 0;
xmax = 4*pi;
nrx = 500;
a = pi/6;

x = linspace(xmin,xmax,nrx);

f = sin(x)
g = a*sin(x) .* cos(x.^3) .* f;

figure
subplot(2,1,1);
plot(x,f,'magenta');
grid on;

subplot(2,1,2);
plot(x,g,'black')