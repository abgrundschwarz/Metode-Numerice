xmin = 0;
xmax = 4*pi;
nrx = 500;
a = pi/6;

x = linspace(xmin,xmax,nrx);

f = sin(x);
g = a.*f.*(x/6*a).*sin(x);

figure
subplot(2,1,1);
plot(x,f,'black');
grid on;

subplot(2,1,2);
plot(x,g,"green")
grid on;