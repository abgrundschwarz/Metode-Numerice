a = 1;
h = 1;

t = linspace(-2*pi,2*pi,500)

x = a*t-h*sin(t);
y = a - h*cos(t);

figure

subplot(2,3,1);
plot(x,y,"red")
title("Cicloida")
grid on


t = linspace(-pi,pi,500)
x = a*(cos(t)).^3;
y = a*(sin(t)).^3;

subplot(2,3,2)
plot(x,y,"green")
title("Astroida")
grid on


a = 8;
b = 5;
t = linspace(0,10*pi,500)
x = (a+b)*cos(t) - b*cos((a/b+1)*t);
y = (a+b)*sin(t) - b*sin((a/b+1)*t);

subplot(2,3,3)
plot(x,y,"magenta")
title("Epicicloida")
grid on


a = 5;
b = 3;
c = 5;
t = linspace(0,6*pi,500)
x = (a+b)*cos(t) - c*cos((a/b+1)*t);
y = (a+b)*sin(t) - c*sin((a/b+1)*t);

subplot(2,3,4)
plot(x,y,"blue")
title("Epitrohoida")
grid on


t = linspace(-3*pi,3*pi,500)
x = (a-b)*cos(t) + b*cos((a/b-1)*t);
y = (a-b)*sin(t) - b*sin((a/b-1)*t);

subplot(2,3,5)
plot(x,y,"black")
title("Hipocicloida")
grid on