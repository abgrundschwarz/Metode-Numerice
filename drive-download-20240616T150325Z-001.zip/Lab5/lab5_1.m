a = 1
theta = linspace(0,4*pi,500)
r = a*theta

figure

subplot(2,2,1)
polarplot(theta,r,"blue")
grid on
title("Spirala lui Arhimede")

a = 1
b = 1.5
theta = linspace(0,2*pi,500)
r = a*exp(theta*cot(b))

subplot(2,2,2)
polarplot(theta,r,"red")
grid on
title("Spirala logaritmica")


subplot(2,2,3)
polarplot(theta,a^2*theta)
grid on
title("Spirala lui Fermat")

p = 0.8
theta = linspace(0,10*pi,500)
r = a*(cos(p.*theta).^(1/p))

subplot(2,2,4)
polarplot(theta,r)
grid on
title("Spirala sinusoidala")
