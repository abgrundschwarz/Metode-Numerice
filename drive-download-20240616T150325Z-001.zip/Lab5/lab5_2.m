r = 1
c = 1
t = linspace(0,8*pi,500)

figure
subplot(1,3,1)
plot3(r*cos(t),r*sin(t),c*t)
grid on
title("Elicea elicoidala")

a = 1
r = 1
t = linspace(0,12*pi,500)

subplot(1,3,2)
plot3(t.*r.*cos(a.*t),t.*r.*sin(a.*t),t)
grid on
title("Spirala conica")

a = 0.1
t = linspace(-14*pi,14*pi,5000)

subplot(1,3,3)
plot3(cos(t)./(sqrt(1+a^2*t.^2)),cos(t)./(sqrt(1+a^2*t.^2)),(-a*t)./(sqrt(1+a^2*t.^2)))