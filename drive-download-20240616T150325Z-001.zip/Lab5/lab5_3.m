a = 1
b = 1
x = linspace(-pi,pi,300)
y = linspace(-pi,pi,300)
[x,y] = meshgrid(x,y)

subplot(2,2,1)
mesh(x,y,x.^2/b^2-y.^2/a^2)
box on
title("Paraboloidul hiperbolic")

x = linspace(-2*pi,2*pi,300)
y = linspace(-2*pi,2*pi,300)
[x,y]=meshgrid(x,y)

subplot(2,2,2)
mesh(x,y,x.^2.*y.^2)
box on
title("Crossed Through")

subplot(2,2,3)
mesh(x,y,x.*(x.^2-3*y.^2))
box on
title("Monkey Saddle")

subplot(2,2,4)
mesh(x,y,(2*x.^2-y).*(y-x.^2))
box on
title("Peano")