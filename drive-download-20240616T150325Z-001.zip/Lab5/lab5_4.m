x = linspace(0.1,100,20)

figure
subplot(2,2,1)
plot(x,sqrt(x).*(x-sqrt(x)))
grid on

subplot(2,2,2)
area(x,sqrt(x).*(x-sqrt(x)))
grid on

subplot(2,2,3)
bar(x,sqrt(x).*(x-sqrt(x)))
grid on

subplot(2,2,4)
stairs(x,sqrt(x).*(x-sqrt(x)))
grid on