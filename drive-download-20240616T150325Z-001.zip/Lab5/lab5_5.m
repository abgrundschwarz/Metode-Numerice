mere = 15;
pere = 10;
caise = 35;
visine = 20;
cirese = 20;

figure

subplot(1,2,1)
pie([mere, pere, caise, visine, cirese], {'Mere', 'Pere', 'Caise', 'Visine', 'Cirese'})

subplot(1,2,2)
pie3([mere, pere, caise, visine, cirese], {'Mere', 'Pere', 'Caise', 'Visine', 'Cirese'})

