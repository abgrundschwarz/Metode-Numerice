x = linspace(-2*pi,2*pi,500)
tic
f = sin(x)
t1 = toc

figure
plot(x,f)
grid on

tic
for i=1:500
    f(i) = sin(x(i))
end
t2 = toc
