x = linspace(-2*pi,2*pi,500)

for i=1:length(x)
    if x(i) < 0
        f(i) = sin(x(i))
    else
        f(i) = cos(x(i))
    end
end

plot(x,f)
grid on