f = @(x) log(x) + 3*x^2 - 4*x - 1;
x0 = input('Introduceti x0: ');
x1 = input('Introduceti x1: ');
delta = input('Eroarea: ');
n = input('Introduceti numarul de iteratii: ');

for i = 1:n
    x2 = (x0*f(x1) - x1*f(x0)) / (f(x1) - f(x0));
    if abs(x2 - x1) < delta
        break;
    end
    x0 = x1;
    x1 = x2;
end

disp(['Root: ', num2str(x2)]);
