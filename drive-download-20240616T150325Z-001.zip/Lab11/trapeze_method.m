f = @(x) x^2-2*x+5;
a = input('a: ');
b = input('b: ');
n = input('n: ');

h = (b-a)/n;
s = 0;
for i=1:1:n-1
    xi = a+i*h;
    s = s + f(xi);
end
I = (h/2)*(f(a)+f(b)+2*s);
disp(I);