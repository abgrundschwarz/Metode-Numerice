f = @(x) x^2-2*x+5;

a = input("a: ");
b = input("b: ");
n = input("n: ");
h = (a+b)/n;

sum_p = 0;
sum_imp = 0;

for i = 1:2:n-1
    xi = a+h*i;
    sum_imp = sum_imp + f(xi);
end

for i = 2:2:n-1
    x2i = a+h*i;
    sum_p = sum_p + f(x2i);
end

I = (h/3)*(f(a)+f(b)+2*sum_p+4*sum_imp);

disp(I);